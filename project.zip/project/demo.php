<?php
// mcrypt_encrypt(cipher, key, data, mode)
echo md5('james');
//sha1()
?>