<?php
$con=mysql_connect("localhost", "root", "");
mysql_select_db("tss_divya", $con);
session_start();
?>